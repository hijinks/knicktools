function DEM = uplus(DEM)
DEM.Z = uplus(DEM.Z);