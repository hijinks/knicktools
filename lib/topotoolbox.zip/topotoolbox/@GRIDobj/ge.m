function OUT = ge(varargin)

funname = 'ge';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});