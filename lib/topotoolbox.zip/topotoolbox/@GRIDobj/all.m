function tf = all(I)


tf = all(I.Z(:));