function OUT = xor(varargin)

funname = 'xor';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});