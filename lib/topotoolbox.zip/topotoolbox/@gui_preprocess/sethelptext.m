function sethelptext(app,string)
% set helptext displayed in gui
%
% sethelptext(app,string)
%
%
set(app.helptext,'String',string);
pause(.1)
end

