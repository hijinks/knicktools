function deletelines(app)
delete(app.lh);
app.lh = [];
end