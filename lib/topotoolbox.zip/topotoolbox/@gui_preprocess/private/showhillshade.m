function showhillshade(~,~,app)
set(app.menu.menuim,'Checked','off')
set(app.menu.menuhs,'Checked','on')
set(app.im,'CData',app.RGB)
end