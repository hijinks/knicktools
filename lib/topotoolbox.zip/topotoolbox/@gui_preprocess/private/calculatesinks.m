function calculatesinks(~,~,app)
app.DEMf = fillsinks(app.DEM);
end